import numpy as np
import sys
import json
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from tensorflow.keras.preprocessing.image import ImageDataGenerator

if __name__ == '__main__':

    if sys.argv[1]:
        # load model
        model = load_model('111511198.h5')

        # load image from image_path_list.txt
        with open(sys.argv[1], 'r') as json_file:
            data = json.load(json_file)

        # Extract the list of image paths
        image_paths = data['image_paths']
        image_predictions = []
        with open('image_predictions.json', 'w') as f:
            f.write('')

        datagen = ImageDataGenerator(rescale=1./255)

        # Iterate through the list of image paths
        for image_path in image_paths:
            # Load and preprocess the image
            img = image.load_img(image_path, target_size=(224, 224))
            img_arr = np.expand_dims(image.img_to_array(img), axis=0)
            img_arr = datagen.standardize(img_arr)

            # Make a prediction using the model
            pred = model.predict(img_arr)

            # Determine if the image is popular based on the prediction result
            is_popular = int(pred > 0.5)  # Convert prediction to 0 or 1

            # Append the prediction result to the list of image predictions
            image_predictions.append(is_popular)

        # Write the updated image predictions list to the JSON file
        with open('image_predictions.json', 'w') as json_file:
            json.dump({"image_predictions": image_predictions},
                      json_file, indent=4)

        print("Prediction results have been appended to 'image_predictions.json'.")

    elif not sys.argv[1]:
        print('Please input the text file name.')
